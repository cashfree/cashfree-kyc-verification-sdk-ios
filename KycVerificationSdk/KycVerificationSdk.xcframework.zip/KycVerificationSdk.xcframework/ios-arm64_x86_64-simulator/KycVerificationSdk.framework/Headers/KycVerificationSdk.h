//
//  KycVerificationSdk.h
//  KycVerificationSdk
//
//  Created by Renu Bisht on 24/06/24.
//

#import <Foundation/Foundation.h>

//! Project version number for KycVerificationSdk.
FOUNDATION_EXPORT double KycVerificationSdkVersionNumber;

//! Project version string for KycVerificationSdk.
FOUNDATION_EXPORT const unsigned char KycVerificationSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KycVerificationSdk/PublicHeader.h>


